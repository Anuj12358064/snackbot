/*CMD
  command: /chooseGame
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var keyboard = {
  keyboard: [
    ["carrom","8bp","soccer"],
    ["🔙 Main Menu"]
  ],
  resize_keyboard: true
};

Api.sendMessage({
  text: "🎮 Please choose game:",
  reply_markup: keyboard
});
