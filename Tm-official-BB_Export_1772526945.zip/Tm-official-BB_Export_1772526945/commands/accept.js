/*CMD
  command: accept
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;

if(user.telegramid != ADMIN){
  return;
}

// Get callback data properly
var data = request.data;

// Example data: accept_123456789
var id = data.split("_")[1];

User.setProperty("credit_user", id, "string");
User.setProperty("waiting_credit_amount", true, "boolean");

Api.answerCallbackQuery({
  callback_query_id: request.id,
  text: "Enter credit amount now."
});

Bot.sendMessage("💰 Enter amount to credit for User ID: " + id);
Bot.runCommand("credit_amount");
