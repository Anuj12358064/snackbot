/*CMD
  command: /removechannel
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;

if(user.telegramid != ADMIN){
  Bot.sendMessage("❌ You are not authorized.");
  return;
}

var existing = Bot.getProperty("business_channel");

if(!existing){
  Bot.sendMessage("⚠️ No channel is currently set.");
  return;
}

Bot.setProperty("business_channel", null);

Bot.sendMessage("✅ Channel removed successfully.");
