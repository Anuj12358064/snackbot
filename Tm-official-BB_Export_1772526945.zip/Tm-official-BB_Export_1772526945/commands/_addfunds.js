/*CMD
  command: /addfunds
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 💰 add fund
  group: 
CMD*/

Bot.sendMessage(
"🏦 *BUSINESS WALLET DEPOSIT*\n\nEnter the amount you want to add (₹):",
{ is_reply: true }
);

Bot.runCommand("deposit_amount_enter");
