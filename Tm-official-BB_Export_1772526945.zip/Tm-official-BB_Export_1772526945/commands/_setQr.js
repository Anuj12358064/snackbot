/*CMD
  command: /setQr
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 📢 setqr
  group: 
CMD*/

if(user.telegramid != Bot.getProperty("single_admin_id")){
  return Api.sendMessage({text:"❌ You are not authorized!"});
}

User.setProperty("upload_qr_mode", true, "boolean");

Bot.sendMessage(
"📸 *QR Upload Mode Activated*\n\nNow send the QR image.",
{ parse_mode: "Markdown" }
);
