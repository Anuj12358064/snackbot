/*CMD
  command: 📦 Stock Check
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var games = ["carrom","8bp","soccer"];
var durations = ["3","10","30"];

var text = 
"━━━━━━━━━━━━━━━━━━━━━━\n" +
"🏦 *SNAKE ENGINE STOCK PANEL*\n" +
"━━━━━━━━━━━━━━━━━━━━━━\n\n" +
"📊 *Live Inventory Status*\n\n";

for(var g in games){
  
  text += "🎮 *" + games[g].toUpperCase() + "*\n";
  text += "──────────────────\n";
  
  for(var d in durations){
    var stock = Bot.getProperty("stock_"+games[g]+"_"+durations[d]);
    if(!stock){ stock = []; }
    
    var count = stock.length;
    var status = count > 0 ? "(🟢) Available" : "(🔴) Out of Stock";
    
    text += 
    "⏳ " + durations[d] + " Days  :  `" + count + "`  " + status + "\n";
  }
  
  text += "\n";
}

text += "━━━━━━━━━━━━━━━━━━━━━━\n";
text += "⚡ Powered by Snake Engine";

Api.sendMessage({
  text: text,
  parse_mode: "Markdown"
});
