/*CMD
  command: /setchannel
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: b

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;

// 🔐 Admin Check
if (user.telegramid != ADMIN){
  Bot.sendMessage("❌ You are not authorized.");
  return;
}

// 📩 Get parameter after command
var params = message.split(" ");

if(params.length < 2){
  Bot.sendMessage("⚠️ Usage:\n/setchannel @yourchannel");
  return;
}

var channel = params[1].trim();

// 🔎 Validate Username
if(!channel.startsWith("@")){
  Bot.sendMessage("❌ Please send channel username like:\n/setchannel @yourchannel");
  return;
}

// 🚫 Check Existing Channel
var existing = Bot.getProperty("business_channel");
if(existing){
  Bot.sendMessage(
    "⚠️ Channel already exists!\n\n" +
    "📢 Current Channel: " + existing + "\n\n" +
    "Use /removechannel first."
  );
  return;
}

// 💾 Save
Bot.setProperty("business_channel", channel, "string");

// ✅ Success
Bot.sendMessage(
  "✅ Channel Successfully Set!\n\n" +
  "📢 Notification Channel:\n" + channel +
  "\n\n⚠️ Make sure bot is ADMIN in that channel."
);
