/*CMD
  command: *
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var waitingDeposit = User.getProperty("waiting_screenshot");

if(waitingDeposit){

  if(!request.photo){
    Bot.sendMessage("❌ Please send payment screenshot image only.");
    return;
  }

  User.setProperty("waiting_screenshot", false, "boolean");

  var amount = User.getProperty("deposit_amount");
  var ADMIN = 6404295823;

  var fileId = request.photo[request.photo.length - 1].file_id;

  Api.sendPhoto({
    chat_id: ADMIN,
    photo: fileId,
    caption:
      "💼 *NEW DEPOSIT REQUEST*\n\n" +
      "👤 Name: " + user.first_name + "\n" +
      "🆔 ID: " + user.telegramid + "\n" +
      "💰 Amount: ₹" + amount,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✅ Accept", callback_data: "/addbalance", style: "success"},
          { text: "❌ Reject", callback_data: "/reject", style: "danger"}
        ]
      ]
    }
  });

  // ✅ Save user ID for Accept button
  User.setProperty("deposit_user_id", user.telegramid, "string");

  Bot.sendMessage("your Payment proof has been submitted.please wait for approval.");
  return;
}

var ADMIN = 6404295823;

if(user.telegramid != ADMIN){
  return;
}

var mode = User.getProperty("upload_qr_mode");

if(!mode){
  return;
}

// Check if photo exists
if(!request.photo){
  Bot.sendMessage("❌ Please send only the QR image.");
  return;
}

// Get highest quality image
var fileId = request.photo[request.photo.length - 1].file_id;

// Save QR
Bot.setProperty("business_qr", fileId, "string");

// Turn off upload mode
User.setProperty("upload_qr_mode", false, "boolean");

Bot.sendMessage(
"✅ *QR Code Updated Successfully!*\n\n🏦 Business Payment System Ready.",
{ parse_mode: "Markdown" }
);
