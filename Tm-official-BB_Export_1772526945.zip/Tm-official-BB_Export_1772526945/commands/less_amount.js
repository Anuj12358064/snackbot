/*CMD
  command: less_amount
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;
if(user.telegramid != ADMIN){ return; }

var targetId = User.getProperty("less_user_id");
var amount = parseFloat(message);

if(isNaN(amount) || amount <= 0){
  Bot.sendMessage("❌ Invalid Amount");
  return;
}

var balance = Libs.ResourcesLib.anotherUserRes("balance", targetId);
var currentBalance = parseFloat(balance.value());

if(isNaN(currentBalance)){ currentBalance = 0; }

if(currentBalance < amount){
  Bot.sendMessage("❌ Insufficient User Balance");
  return;
}

// Deduct Balance
balance.set(currentBalance - amount);

// ━━━━━━━━━━━━━━━━━━━
// 🔔 ADMIN NOTIFICATION
// ━━━━━━━━━━━━━━━━━━━
Api.sendMessage({
  chat_id: ADMIN,
  text:
  "╔═══════════════════════════╗\n" +
  "   🚨 BALANCE DEDUCTED SUCCESS\n" +
  "╠═══════════════════════════╣\n" +
  "  🆔 User ID : " + targetId + "\n" +
  "  💸 Deducted : ₹ " + amount.toFixed(2) + "\n" +
  "  💰 New Balance : ₹ " + (currentBalance - amount).toFixed(2) + "\n" +
  "╚═══════════════════════════╝",
  parse_mode: "Markdown"
});

// ━━━━━━━━━━━━━━━━━━━
// 🔔 USER NOTIFICATION
// ━━━━━━━━━━━━━━━━━━━
Api.sendMessage({
  chat_id: targetId,
  text:
  "╔═══════════════════════════╗\n" +
  "     ⚠️ ACCOUNT NOTICE\n" +
  "╠═══════════════════════════╣\n" +
  "  💸 Amount Deducted : ₹ " + amount.toFixed(2) + "\n" +
  "  💰 Current Balance : ₹ " + (currentBalance - amount).toFixed(2) + "\n" +
  "  🔐 If this is a mistake, contact support.\n" +
  "╚═══════════════════════════╝",
  parse_mode: "Markdown"
});

Bot.sendMessage("✅ Balance Removed Successfully.");
