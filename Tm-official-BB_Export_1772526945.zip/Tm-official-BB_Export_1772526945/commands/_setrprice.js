/*CMD
  command: /setrprice
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = 6404295823;

if(user.telegramid != admin){
  Bot.sendMessage("❌ Admin only");
  return;
}

Bot.sendMessage(
"Send in this format:\n\n"+
"game duration price\n\n"+
"Example:\ncarrom 7 99"
);

Bot.runCommand("/setprice_confirm");
