/*CMD
  command: /addstock
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 🛍️ add key's
  group: 
CMD*/

if(user.telegramid != Bot.getProperty("single_admin_id")){
  return Api.sendMessage({text:"❌ You are not authorized!"});
}

var args = message.split(" ");

// ✅ Check if all arguments are present
// args[0] is /addstock, args[1] is game, args[2] is duration, args[3] is key
if (!args[1] || !args[2] || !args[3]) {
  Api.sendMessage({ 
    text: "❌ <b>Invalid Format!</b>\n\n" +
          "Please use exactly:\n" +
          "<code>/addstock [game] [duration] [key]</code>\n\n" +
          "<i>Example: /addstock carrom 3 xxxxxx</i>",
    parse_mode: "HTML" 
  });
  return; // Stop the script here
}

var game = args[1];
var duration = args[2];
var key = args[3];

// Load current stock
var stock = Bot.getProperty("stock_" + game + "_" + duration);
if (!stock) { stock = []; }

// Add new key to the list
stock.push(key);

// Save back to database
Bot.setProperty("stock_" + game + "_" + duration, stock, "json");

// ✅ Success Message
Api.sendMessage({ 
  text: "✅ <b>Stock Added Successfully!</b>\n" +
        "────────────────────\n" +
        "🎮 <b>Game:</b> " + game + "\n" +
        "⏳ <b>Duration:</b> " + duration + " Days\n" +
        "🔑 <b>Key:</b> <code>" + key + "</code>",
  parse_mode: "HTML" 
});

