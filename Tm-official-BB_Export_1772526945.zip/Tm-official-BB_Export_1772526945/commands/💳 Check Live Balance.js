/*CMD
  command: 💳 Check Live Balance
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🏦 GOLD LUXURY BANK DASHBOARD
//━━━━━━━━━━━━━━━━━━━━━━━━━━

var balance = Libs.ResourcesLib.userRes("balance");

// Safety Check
if (typeof balance.value() !== "number") {
  balance.set(0);
}

var userBalance = parseFloat(balance.value());
if (isNaN(userBalance)) { 
  userBalance = 0; 
}

// User Info
var username = user.username ? "@" + user.username : "Not Set";
var userId = user.telegramid;

// Premium Gold Bank Dashboard
Api.sendMessage({
  text:
  "╔═══════════════════════════╗\n" +
  "        👑  SNAKE ENGINE PANEL  👑\n" +
  "╠═══════════════════════════╣\n" +
  "  🏦 Account Holder\n" +
  "  👤 Username : " + username + "\n" +
  "  🆔 User ID   : " + userId + "\n" +
  "╠═══════════════════════════╣\n" +
  "  💰 Available Balance\n" +
  "      ₹ " + userBalance.toFixed(2) + "\n" +
  "╠═══════════════════════════╣\n" +
  "  ✨ Premium • Secure • Trusted\n" +
  "  🔐 Bank-Level Protection Active\n" +
  "╚═══════════════════════════╝",
  parse_mode: "Markdown"
});
