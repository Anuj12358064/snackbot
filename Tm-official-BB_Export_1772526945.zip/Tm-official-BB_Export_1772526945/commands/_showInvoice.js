/*CMD
  command: /showInvoice
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var duration = User.getProperty("duration");
var game = User.getProperty("game");

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💰 GET PRICE
//━━━━━━━━━━━━━━━━━━━━━━━━━━
var price = Bot.getProperty("price_" + game + "_" + duration);
if (!price || isNaN(price)) { price = 0; }

price = Number(price);
price = Math.round(price * 100) / 100;

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📦 GET STOCK
//━━━━━━━━━━━━━━━━━━━━━━━━━━
var stock = Bot.getProperty("stock_" + game + "_" + duration);
if (!stock || !Array.isArray(stock)) { stock = []; }

var stockCount = stock.length;
var stockStatus = stockCount > 0 
  ? "🟢 <b>Available</b>" 
  : "🔴 <b>Out of Stock</b>";

// Save price for purchase step
User.setProperty("buy_price", price);

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💳 FORMAT PRICE
//━━━━━━━━━━━━━━━━━━━━━━━━━━
var formattedPrice = price.toFixed(2);

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎛 KEYBOARD
//━━━━━━━━━━━━━━━━━━━━━━━━━━
var keyboard = {
  keyboard: [
    ["✅ Confirm Purchase"],
    ["❌ Cancel", "🔙 Main Menu"]
  ],
  resize_keyboard: true
};

//━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🧾 PREMIUM INVOICE DESIGN
//━━━━━━━━━━━━━━━━━━━━━━━━━━
Api.sendMessage({
  text:
  "╔══════════════════════╗\n"+
  "🧾 <b>PURCHASE INVOICE</b>\n"+
  "╚══════════════════════╝\n\n"+
  
  "👤 <b>Buyer</b>\n"+
  "• Name: " + user.first_name + "\n"+
  "• User ID: <code>" + user.telegramid + "</code>\n\n"+
  
  "🎮 <b>Product Details</b>\n"+
  "• Game: " + game.toUpperCase() + "\n"+
  "• Duration: " + duration + " Days\n\n"+
  
  "📦 <b>Stock Information</b>\n"+
  "• Available Keys: " + stockCount + "\n"+
  "• Status: " + stockStatus + "\n\n"+
  
  "━━━━━━━━━━━━━━━━━━━━━━\n"+
  "💰 <b>Total Payable</b>\n"+
  "₹ " + formattedPrice + "\n"+
  "━━━━━━━━━━━━━━━━━━━━━━\n\n"+
  
  "⚠️ <i>Please confirm to complete your purchase.</i>",
  
  parse_mode: "HTML",
  reply_markup: keyboard
});
