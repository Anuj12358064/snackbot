/*CMD
  command: deposit_amount_enter
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var amount = parseFloat(message);

if(isNaN(amount) || amount <= 0){
  Bot.sendMessage("❌ Please enter valid amount.");
  return;
}

User.setProperty("deposit_amount", amount, "float");

var qr = Bot.getProperty("business_qr");
var upi = Bot.getProperty("business_upi");

if(!qr || !upi){
  Bot.sendMessage("⚠️ Payment system not configured.");
  return;
}

Api.sendPhoto({
  photo: qr,
  caption:
  "🏦 *OFFICIAL PAYMENT GATEWAY*\n\n" +
  "💰 Amount: ₹" + amount + "\n\n" +
  "📲 UPI ID: `" + upi + "`\n\n" +
  "1️⃣ Complete Payment\n" +
  "2️⃣ Send Screenshot Here",
  parse_mode: "Markdown"
});

User.setProperty("waiting_screenshot", true, "boolean");

Bot.runCommand("/deposit_screenshot")
