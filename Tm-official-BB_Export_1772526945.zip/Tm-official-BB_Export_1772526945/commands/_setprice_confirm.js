/*CMD
  command: /setprice_confirm
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = 6404295823;

if(user.telegramid != admin){ return; }

var data = message.split(" ");

if(data.length < 3){
  Bot.sendMessage("❌ Wrong format");
  return;
}

var game = data[0];
var duration = data[1];
var price = parseFloat(data[2]);

Bot.setProperty(
  "reseller_price_"+game+"_"+duration,
  price,
  "float"
);

Bot.sendMessage(
"✅ Reseller price set\n\n"+
"🎮 Game: "+game+
"\n⏳ Duration: "+duration+
"\n💰 Price: ₹"+price
);
