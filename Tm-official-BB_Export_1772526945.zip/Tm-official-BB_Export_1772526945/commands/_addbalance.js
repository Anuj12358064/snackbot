/*CMD
  command: /addbalance
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if(request.data == "/addbalance") {
  // ━━━━━━━━━━━━━━━━━━
  // ✅ BUSINESS DEPOSIT ACCEPT HANDLER
  // ━━━━━━━━━━━━━━━━━━

  var ADMIN = 6404295823;

  // Only admin can accept
  if(user.telegramid != ADMIN){
    return;
  }

  // Get user info from properties
  var depositUserId = User.getProperty("deposit_user_id"); 
  var depositAmount = User.getProperty("deposit_amount");

  // Validate deposit info
  if(!depositUserId || !depositAmount){
    Bot.sendMessage("❌ Error: Missing deposit info.");
    return;
  }

  // Ensure depositAmount is a number
  depositAmount = Number(depositAmount);
  if(isNaN(depositAmount) || depositAmount <= 0){
    Bot.sendMessage("❌ Error: Invalid deposit amount.");
    return;
  }

  // Add balance
  var userBalance = Libs.ResourcesLib.anotherUserRes("balance", depositUserId);
  userBalance.add(depositAmount);

  // ✅ Notify user
  Api.sendMessage({
    chat_id: depositUserId,
    text:
`💎 <b>Deposit Approved!</b>
────────────────────
👤 User ID: <code>${depositUserId}</code>
💰 Amount Added: ₹${depositAmount}
💼 Your new balance has been updated successfully!
────────────────────
Thank you for choosing <b>TBS Business Banking</b>.`,
    parse_mode: "HTML"
  });

  // ✅ Notify admin
  Bot.sendMessage(
`💼 <b>Deposit Accepted Successfully!</b>
────────────────────
👤 User ID: <code>${depositUserId}</code>
💰 Amount Added: ₹${depositAmount}
💳 Total Balance Updated ✅
────────────────────`,
    { parse_mode: "HTML" }
  );

  // ✅ Notify channel @tbsgaming1814
  var channelId = "@tbschating1819"; 
  Api.sendMessage({
    chat_id: channelId,
    text:
`📢 <b>New Deposit Processed!</b>
────────────────────
👤 User ID: <code>${depositUserId}</code>
💰 Amount: ₹${depositAmount}
💼 Status: Approved
────────────────────
<i>TBS Gaming Business System</i>`,
    parse_mode: "HTML"
  });

  // Clear temporary properties safely
  User.setProperty("deposit_user_id", "", "string");
  User.setProperty("deposit_amount", 0, "number");

  // ✅ Confirm to admin in bot
  Bot.sendMessage("✅ Deposit approved and balance updated successfully for User ID: " + depositUserId);
}

