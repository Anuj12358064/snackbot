/*CMD
  command: generate_invoice
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var userId = User.getProperty("credit_user");
var amount = parseFloat(message);

Api.sendDocument({
  chat_id: userId,
  document: "file_000000003d7071faa309dae0c73f6c21",
  caption:
  "🧾 *OFFICIAL DEPOSIT RECEIPT*\n\n" +
  "👤 User ID: " + userId + "\n" +
  "💰 Amount: ₹" + amount + "\n" +
  "Status: SUCCESS\n\n" +
  "Thank you for choosing our business.",
  parse_mode: "Markdown"
});
