/*CMD
  command: /addresell
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// 🔐 CHANGE THIS TO YOUR ADMIN ID
var admin = 6404295823;

if(user.telegramid != admin){
  Bot.sendMessage("❌ Admin only");
  return;
}

Bot.sendMessage(
"Send in this format:\n\n"+
"game duration normal_price reseller_price\n\n"+
"Example:\ncarrom 7 120 90"
);

Bot.runCommand("setprice_done");
