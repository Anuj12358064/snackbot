/*CMD
  command: 👤 My Order's
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// --- SAVE PURCHASED KEY TO "MY ORDERS" ---
var myOrders = User.getProperty("my_orders");
if (!Array.isArray(myOrders)) {
  myOrders = [];
}

// Create new order entry
var newOrder = {
  invoiceId: invoiceId,
  product: game.toUpperCase(),
  duration: duration + " Days",
  licenseKey: key,
  amountPaid: "₹ " + price.toFixed(2),
  remainingBalance: "₹ " + remaining.toFixed(2),
  status: "SUCCESS ✅",
  date: new Date().toLocaleString()
};

// Add new order to the top (latest first)
myOrders.unshift(newOrder);

// Save back to user properties
User.setProperty("my_orders", myOrders, "json");

// --- FORMAT ORDERS IN PAGES OF 5 ---
var pageSize = 5;
var totalPages = Math.ceil(myOrders.length / pageSize);

// Get first page (or you can implement page navigation)
var pageOrders = myOrders.slice(0, pageSize);

// Prepare business-style message
var ordersText = "<b>👤 MY ORDERS (Page 1/" + totalPages + ")</b>\n━━━━━━━━━━━━━━━━━━━━━━\n";
pageOrders.forEach(function(order, index){
  ordersText +=
    "<b>" + (index + 1) + ". Invoice ID :</b> <code>" + order.invoiceId + "</code>\n" +
    "<b>Product   :</b> " + order.product + "\n" +
    "<b>Duration  :</b> " + order.duration + "\n" +
    "<b>License   :</b> <code>" + order.licenseKey + "</code>\n" +
    "<b>Amount    :</b> " + order.amountPaid + "\n" +
    "<b>Balance   :</b> " + order.remainingBalance + "\n" +
    "<b>Status    :</b> " + order.status + "\n" +
    "<b>Date      :</b> " + order.date + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━━\n";
});

// Send to user
Api.sendMessage({ chat_id: user.telegramid, text: ordersText, parse_mode: "HTML" });
