/*CMD
  command: /reject
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// Admin ID
var ADMIN = 6404295823;

// Make sure the admin is sending this command
if (user.telegramid != ADMIN) {
  Bot.sendMessage("❌ You are not allowed to use this command.");
  return;
}

// Check if params exist
if (!params || params.indexOf(" ") === -1) {
  Bot.sendMessage("❌ Usage: /reject user_id reason\nExample: /reject 123456 Payment invalid");
  return;
}

// Split user ID and reason
var parts = params.split(" ");
var rejectedUserId = parseInt(parts[0]); // ensure it's a number
var reason = parts.slice(1).join(" ");

// Validate user ID
if (isNaN(rejectedUserId)) {
  Bot.sendMessage("❌ Invalid user ID.");
  return;
}

// Notify the user
Api.sendMessage({
  chat_id: rejectedUserId,
  text: "❌ Your request has been rejected by the admin.\nReason: " + reason
});

// Notify the admin
Api.sendMessage({
  chat_id: ADMIN,
  text: "⚠️ Rejection done!\nUser ID: " + rejectedUserId + "\nReason: " + reason
});

// Optional: Notify log channel
var logChannel = Bot.getProperty("log_channel"); // @channel or numeric ID
if (logChannel) {
  Api.sendMessage({
    chat_id: logChannel,
    text: "⚠️ Request Rejected\nUser ID: " + rejectedUserId + "\nReason: " + reason
  });
}

// Confirm action in bot
Bot.sendMessage("✅ User has been notified about rejection.");
