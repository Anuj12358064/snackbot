/*CMD
  command: /start
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 🔙 main menu
  group: 
CMD*/

// 🔐 Auto set admin when first user starts
var adminId = Bot.getProperty("single_admin_id");
if (!adminId) {
  Bot.setProperty("single_admin_id", user.telegramid, "string");
  Bot.sendMessage("✅ Admin set successfully: " + user.telegramid+"\n\n⚙️ Access the panel /admin\nPowered By @tbsgaming09");
}

// Delete previous menu message safely
var msg_id = User.getProperty("last_msg");

if(msg_id){
  Api.deleteMessage({
    message_id: msg_id
  });
}

// Send new menu
var sent = Api.sendMessage({
  text: "🎮 *Welcome to Premium Key Store*\n\nPlease choose an option:",
  parse_mode: "Markdown",
  reply_markup: {
    keyboard: [
      ["🛒 Buy 3-Day Key","🛒 Buy 10-Day Key"],
      ["🛒 Buy 30-Day Key","🛒 Buy 90-Day Key"],
      ["💰 Add Fund","💳 Check Live Balance"],
      ["📦 Stock Check"]
    ],
    resize_keyboard: true
  }
});

// Save message id properly
User.setProperty("last_msg", request.message_id);
