/*CMD
  command: /setprice
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 🔥 setprice
  group: 
CMD*/

if(user.telegramid != Bot.getProperty("single_admin_id")){
  return Api.sendMessage({text:"❌ You are not authorized!"});
}

var args = message.split(" ");

if(args.length < 4){
  Api.sendMessage({ text: "Usage:\n/setprice game duration amount" });
  return;
}

var game = args[1];
var duration = args[2];
var amount = parseFloat(args[3]);

Bot.setProperty("price_"+game+"_"+duration, amount, "integer");

Api.sendMessage({
  text: "✅ Price Set\n\n🎮 "+game+"\n⏳ "+duration+" Days\n💰 ₹"+amount
});
