/*CMD
  command: /addreseller_confirm
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = 6404295823;

if(user.telegramid != admin){ return; }

var id = message;

if(!id){
  Bot.sendMessage("❌ Invalid ID");
  return;
}

Bot.setProperty("reseller_"+id, true, "boolean");

Bot.sendMessage("✅ User "+id+" added as Reseller 👑");
