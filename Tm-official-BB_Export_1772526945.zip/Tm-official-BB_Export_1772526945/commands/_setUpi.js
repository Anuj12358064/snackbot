/*CMD
  command: /setUpi
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: *Please Enter You Upi Id To Set...*

  <<KEYBOARD

  KEYBOARD
  aliases: 🎯 setupi id
  group: 
CMD*/

let adminId = Bot.getProperty("single_admin_id");
if (user.telegramid != Number(adminId)) {
  return Bot.sendMessage("access denied!");
}

if(!message){
  Bot.sendMessage("❌ Usage:\n/setUpi yourupi@bank");
  return;
}

Bot.setProperty("business_upi", message.trim(), "string");

Bot.sendMessage("✅ *UPI ID Updated Successfully*\n\n📲 New UPI: `" + message + "`", { parse_mode: "Markdown" });
