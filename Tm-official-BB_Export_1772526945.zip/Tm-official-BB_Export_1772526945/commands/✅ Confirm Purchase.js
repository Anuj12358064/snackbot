/*CMD
  command: ✅ Confirm Purchase
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;
var CHANNEL_ID = "@tbschating1819"; 

var balance = Libs.ResourcesLib.userRes("balance");
var rawBalance = balance.value();

// Ensure balance is valid
if (typeof rawBalance !== "number" || isNaN(rawBalance)) {
  balance.set(0);
  rawBalance = 0;
}
var userBalance = Math.round(Number(rawBalance) * 100) / 100;

// Check product price
var price = Number(User.getProperty("buy_price"));
if (!price || isNaN(price) || price <= 0) {
  Api.sendMessage({ text: "❌ <b>Invalid product price!</b>", parse_mode: "HTML" });
  Bot.runCommand("/start");
  return;
}

// Check balance
if (userBalance < price) {
  Api.sendMessage({ text: "❌ <b>Insufficient funds!</b>\nPlease add funds to continue.", parse_mode: "HTML" });
  Bot.runCommand("/start");
  return;
}

// Check session/game info
var game = User.getProperty("game");
var duration = User.getProperty("duration");
if (!game || !duration) {
  Api.sendMessage({ text: "❌ <b>Session expired!</b>", parse_mode: "HTML" });
  Bot.runCommand("/start");
  return;
}

// Fetch and validate stock
var stock = Bot.getProperty("stock_" + game + "_" + duration);
if (!Array.isArray(stock) || stock.length === 0) {
  Api.sendMessage({ text: "⚠️ <b>Out of stock!</b>\nPlease check back later.", parse_mode: "HTML" });
  Bot.runCommand("/start");
  return;
}

// --- PROCESS SALE ---
var key = stock.shift();
Bot.setProperty("stock_" + game + "_" + duration, stock, "json");
balance.add(-price);

var remaining = Math.round(Number(balance.value()) * 100) / 100;
var invoiceId = "INV-" + user.telegramid + "-" + Math.floor(Math.random() * 10000);
var clientName = user.first_name ? user.first_name : "Customer";
var username = user.username ? "@" + user.username : "No Username";

// Get Kolkata time
var kolkataTime = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: true });

// --- USER INVOICE MESSAGE (FIXED TAGS) ---
var invoiceText =
"<b>━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
"        <b>OFFICIAL INVOICE</b>\n" +
"<b>━━━━━━━━━━━━━━━━━━━━━━</b>\n\n" +
"<b>Invoice ID :</b> <code>" + invoiceId + "</code>\n" +
"<b>Client     :</b> " + clientName + "\n" +
"<b>User ID    :</b> <code>" + user.telegramid + "</code>\n" +
"<b>Product    :</b> " + game.toUpperCase() + "\n" +
"<b>Duration   :</b> " + duration + " Days\n\n" +
"<b>License Key:</b>\n<code>" + key + "</code>\n\n" +
"<b>Amount Paid       :</b> ₹ " + price.toFixed(2) + "\n" +
"<b>Remaining Balance :</b> ₹ " + remaining.toFixed(2) + "\n" +
"<b>Purchase Time     :</b> " + kolkataTime + "\n\n" +
"<b>Status :</b> SUCCESS ✅\n" + // Fixed the extra </b> here
"<b>━━━━━━━━━━━━━━━━━━━━━━</b>";

// --- CHANNEL NOTIFICATION ---
var channelText = 
"<b>🚀 NEW SUCCESSFUL PURCHASE</b>\n" +
"━━━━━━━━━━━━━━━━━━━━━━\n" +
"👤 <b>Username:</b> " + username + "\n" +
"🆔 <b>User ID:</b> <code>" + user.telegramid + "</code>\n" +
"💰 <b>Amount Paid:</b> ₹ " + price.toFixed(2) + "\n" +
"🔑 <b>Key:</b> <code>Hidden</code>\n" +
"🧾 <b>Invoice ID:</b> <code>" + invoiceId + "</code>\n" +
"🎮 <b>Product:</b> " + game.toUpperCase() + "\n" +
"⏳ <b>Duration:</b> " + duration + " Days\n" +
"💳 <b>Remaining Balance:</b> ₹ " + remaining.toFixed(2) + "\n" +
"📅 <b>Purchase Time :</b> " + kolkataTime + "\n" +
"✅ <b>Status:</b> SUCCESSFUL\n" +
"━━━━━━━━━━━━━━━━━━━━━━";

// --- SEND MESSAGES ---
// Use Bot.sendMessage for simple calls or keep Api.sendMessage for specific IDs
try {
  Api.sendMessage({ chat_id: user.telegramid, text: invoiceText, parse_mode: "HTML" });
  Api.sendMessage({ chat_id: CHANNEL_ID, text: channelText, parse_mode: "HTML" });
  Api.sendMessage({
    chat_id: ADMIN,
    text:
      "<b>━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
      "🏦 <b>PURCHASE NOTIFICATION</b>\n" +
      "<b>━━━━━━━━━━━━━━━━━━━━━━</b>\n\n" +
      "📥 <b>New Sale Completed</b>\n" +
      "🆔 <b>Invoice ID :</b> <code>" + invoiceId + "</code>\n" +
      "👤 <b>Customer  :</b> " + clientName + "\n" +
      "🎮 <b>Product   :</b> " + game.toUpperCase() + "\n" +
      "⏳ <b>Duration  :</b> " + duration + " Days\n" +
      "💰 <b>Amount    :</b> ₹ " + price.toFixed(2) + "\n" +
      "📦 <b>Stock Left:</b> " + stock.length + "\n" +
      "🕒 <b>Purchase Time :</b> " + kolkataTime + "\n\n" +
      "🔗 Check your proof channel for details",
    parse_mode: "HTML"
  });

  Bot.runCommand("/start");
} catch (e) {
  Bot.sendMessage("❌ Error sending notifications: " + e.message);
}

