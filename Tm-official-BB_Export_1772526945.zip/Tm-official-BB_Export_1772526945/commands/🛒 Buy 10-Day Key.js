/*CMD
  command: 🛒 Buy 10-Day Key
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

User.setProperty("duration","10");
Bot.runCommand("/chooseGame");
