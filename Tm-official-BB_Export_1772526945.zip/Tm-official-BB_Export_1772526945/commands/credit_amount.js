/*CMD
  command: credit_amount
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if(user.telegramid != 6404295823){ return; }

var amount = parseFloat(message);
if(isNaN(amount) || amount <= 0){
  Bot.sendMessage("❌ Invalid amount.");
  return;
}

var userId = User.getProperty("credit_user");
var channel = Bot.getProperty("business_channel");

// Add balance
Libs.ResourcesLib.anotherUserRes("balance", userId).add(amount);

// Notifications
Api.sendMessage({
  chat_id: userId,
  text:
  "✅ *DEPOSIT APPROVED*\n\n" +
  "💰 Amount Credited: ₹" + amount + "\n\n" +
  "Invoice PDF attached below.",
  parse_mode: "Markdown"
});

Api.sendMessage({
  chat_id: 6404295823,
  text: "✅ Deposit Approved\nUser: " + userId + "\nAmount: ₹" + amount
});

if(channel){
  Api.sendMessage({
    chat_id: channel,
    text:
    "🏦 *NEW SUCCESSFUL DEPOSIT*\n\n" +
    "👤 User ID: " + userId + "\n" +
    "💰 Amount: ₹" + amount,
    parse_mode: "Markdown"
  });
}

// Generate PDF via external command
Bot.runCommand("generate_invoice");
