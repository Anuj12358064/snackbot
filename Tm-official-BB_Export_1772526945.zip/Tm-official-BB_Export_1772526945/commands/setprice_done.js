/*CMD
  command: setprice_done
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = 6404295823;

if(user.telegramid != admin){ return; }

var data = message.split(" ");

if(data.length < 4){
  Bot.sendMessage("❌ Wrong format\n\nExample:\ncarrom 7 120 90");
  return;
}

var game = data[0].toLowerCase();
var duration = data[1];
var normal_price = parseFloat(data[2]);
var reseller_price = parseFloat(data[3]);

if(isNaN(normal_price) || isNaN(reseller_price)){
  Bot.sendMessage("❌ Price must be number");
  return;
}

// ✅ Save normal price
Bot.setProperty(
  "price_"+game+"_"+duration,
  normal_price,
  "float"
);

// ✅ Save reseller price
Bot.setProperty(
  "reseller_price_"+game+"_"+duration,
  reseller_price,
  "float"
);

Bot.sendMessage(
"✅ Price Updated Successfully\n\n"+
"🎮 Game: "+game+
"\n⏳ Duration: "+duration+" Days"+
"\n💰 Normal Price: ₹"+normal_price+
"\n👑 Reseller Price: ₹"+reseller_price
);
