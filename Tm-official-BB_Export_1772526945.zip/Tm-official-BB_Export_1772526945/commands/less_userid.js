/*CMD
  command: less_userid
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var ADMIN = 6404295823;
if(user.telegramid != ADMIN){ return; }

var targetId = message;
User.setProperty("less_user_id", targetId, "string");

// Ask Amount
Bot.sendMessage(
  "╔═══════════════════════════╗\n" +
  "      💰 ENTER DEDUCT AMOUNT\n" +
  "╠═══════════════════════════╣\n" +
  "  🆔 User ID : " + targetId + "\n" +
  "  💸 Enter Amount to Deduct\n" +
  "╚═══════════════════════════╝",
  { is_reply: true }
);

Bot.runCommand("less_amount");
