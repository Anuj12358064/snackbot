/*CMD
  command: /xhange
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: ueerid

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let adminId = message
Bot.setProperty("single_admin_id", adminId, "string");
Bot.sendMessage("✅ Admin set successfully: " + adminId);
