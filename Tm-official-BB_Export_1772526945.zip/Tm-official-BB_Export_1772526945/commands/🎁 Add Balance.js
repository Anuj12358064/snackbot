/*CMD
  command: 🎁 Add Balance
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: *Sorry, You Cannot AddBalance, It's Automatic in "AddFund" Menu...*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

