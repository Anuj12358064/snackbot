/*CMD
  command: 🛒 Buy 3-Day Key
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

User.setProperty("duration","3");

Bot.runCommand("/chooseGame");
