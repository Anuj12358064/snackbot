/*CMD
  command: /removebal
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 🎉 remove balance
  group: 
CMD*/

// Only Admin Access
if(user.telegramid != Bot.getProperty("single_admin_id")){
  return Api.sendMessage({text:"❌ You are not authorized!"});
}

// Ask for User ID
Bot.sendMessage(
  "╔═══════════════════════════╗\n" +
  "      👑 ACTION: RMVE BALANCE\n" +
  "╠═══════════════════════════╣\n" +
  "  🔎 Enter User ID to Remove Balance\n" +
  "╚═══════════════════════════╝",
  { is_reply: true }
);

Bot.runCommand("less_userid");
