/*CMD
  command: /admin
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let adminId = Bot.getProperty("single_admin_id");
if (user.telegramid != Number(adminId)) {
  return Bot.sendMessage("Admin access denied!");
}

// Delete previous menu message safely
var msg_id = User.getProperty("last_msg");

if(msg_id){
  Api.deleteMessage({
    message_id: msg_id
  });
}

// Send new menu
var sent = Api.sendMessage({
  text: "📢 *Welcome to Admin controls*\n\nPlease choose an option to access:",
  parse_mode: "Markdown",
  reply_markup: {
    keyboard: [
      ["🎁 Add Balance","🎉 Remove Balance"],
      ["📢 SetQr","🎯 SetUpi Id"],
      ["🔥 Setprice","🛍️ Add Key's"],
      ["🔙 main menu"]
    ],
    resize_keyboard: true
  }
});

// Save message id properly
User.setProperty("last_msg", request.message_id);
